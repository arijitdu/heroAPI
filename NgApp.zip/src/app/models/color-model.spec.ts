import { ColorModel } from './color-model';

describe('ColorModel', () => {
  it('should create an instance', () => {
    expect(new ColorModel()).toBeTruthy();
  });
});
