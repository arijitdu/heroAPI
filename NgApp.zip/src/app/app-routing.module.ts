import { NewColorComponent } from './new-color/new-color.component';
import { MyOwnColorComponent } from './my-own-color/my-own-color.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ColorsComponent } from './colors/colors.component';
import { CarColorComponent } from './car-color/car-color.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/colors' },
  {
    path: 'colors', component: ColorsComponent, children: [
      { path: 'new', component: NewColorComponent,  pathMatch:'full' },
      { path: ':hexValue', component: CarColorComponent,  pathMatch:'full' }
    ]
  },
  { path: 'my-vehicle', component: MyOwnColorComponent }
];
/** /colors/new -> /colors/new */
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
